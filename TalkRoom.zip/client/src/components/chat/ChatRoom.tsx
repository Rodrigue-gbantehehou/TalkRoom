import { useEffect, useState } from 'react';
import { MessageList } from './MessageList';
import { MessageInput } from './MessageInput';
import { UsersList } from './UsersList';
import { RoomInfo } from './RoomInfo';
import { useChatContext } from '@/context/ChatContext';
import { useWebSocket } from '@/hooks/useWebSocket';
import { useWebRTC } from '@/hooks/useWebRTC';
import { useEncryption } from '@/hooks/useEncryption';
import { CompressionService } from '@/lib/compression';
import { Message } from '@/types/chat';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { SessionStorageService } from '@/lib/sessionStorage';
import { FaBolt, FaTimes, FaShare, FaFileExport, FaTrash, FaShieldAlt, FaUsers, FaChartBar, FaLink, FaClipboard, FaShareAlt, FaDoorOpen, FaSun, FaMoon, FaComments, FaBan } from "react-icons/fa";
import { apiRequest } from '@/lib/queryClient';


interface ChatRoomProps {
  roomCode: string;
  username: string;
  role: 'user' | 'admin';
  onLeave: () => void;
}

export function ChatRoom({ roomCode, username, role, onLeave }: ChatRoomProps) {
  const {
    messages,
    participants,
    currentUser,
    typingUsers,
    messageCount,
    isConnected,
    roomClosed,
    addMessage,
    updateParticipants,
    setCurrentUser,
    setIsConnected,
    addTypingUser,
    removeTypingUser,
    clearMessages,
    loadMessages,
    incrementMessageCount,
    addReaction,
    closeRoom
  } = useChatContext();

  const { toast } = useToast();
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState<'connecting' | 'connected' | 'disconnected' | 'error'>('connecting');
  const [showMenu, setShowMenu] = useState(false);
  const { encryptMessage, decryptMessage, generateRoomKey, importRoomKey } = useEncryption();

  // Function to load existing messages from the database
  const loadExistingMessages = async () => {
    try {
      const response = await apiRequest('GET', `/api/rooms/${roomCode}/messages`);
      const storedMessages = await response.json();
      
      // Convert stored messages to frontend format
      const formattedMessages: Message[] = storedMessages.map((msg: any) => ({
        id: msg.id,
        content: msg.content,
        senderId: msg.senderId,
        senderName: msg.senderName,
        timestamp: new Date(msg.timestamp).getTime(),
        type: msg.type,
        imageUrl: msg.imageUrl
      }));

      // Load messages into the chat context
      loadMessages(formattedMessages);
    } catch (error) {
      console.error('Failed to load existing messages:', error);
      // Don't show an error toast as this is not critical functionality
    }
  };

  const handleWebSocketMessage = async (data: any) => {
    switch (data.type) {
      case 'joined_room':
        setCurrentUser({
          id: data.userId,
          username: data.username,
          role,
          isOnline: true
        });
        setIsConnected(true);
        
        // Generate or import encryption key
        await generateRoomKey(roomCode);
        
        // Load existing messages from database
        await loadExistingMessages();
        
        // Add welcome message
        addMessage({
          id: `system-${Date.now()}`,
          content: 'Bienvenue dans la messagerie ! 🎉',
          senderId: 'system',
          senderName: 'Système',
          timestamp: Date.now(),
          type: 'system'
        });
        break;

      case 'user_joined':
        addMessage({
          id: `system-${Date.now()}`,
          content: `${data.username} a rejoint la conversation`,
          senderId: 'system',
          senderName: 'Système',
          timestamp: Date.now(),
          type: 'system'
        });
        break;

      case 'user_left':
        addMessage({
          id: `system-${Date.now()}`,
          content: `${data.username} a quitté la conversation`,
          senderId: 'system',
          senderName: 'Système',
          timestamp: Date.now(),
          type: 'system'
        });
        break;

      case 'participants_update':
        updateParticipants(data.participants);
        break;

      case 'typing_start':
        if (data.username !== username) {
          addTypingUser(data.username);
        }
        break;

      case 'typing_stop':
        removeTypingUser(data.username);
        break;

      case 'webrtc_signal':
        // Handle WebRTC signaling
        if (data.signal.type === 'offer') {
          const answer = await createAnswer(data.fromUserId, data.signal);
          sendWebSocketMessage({ 
            type: 'webrtc_signal', 
            targetUserId: data.fromUserId, 
            signal: answer 
          });
        } else if (data.signal.type === 'answer') {
          await handleAnswer(data.fromUserId, data.signal);
        } else if (data.signal.type === 'ice-candidate') {
          await handleIceCandidate(data.fromUserId, data.signal);
        }
        break;

      case 'message_received':
        // Handle messages received via WebSocket broadcast
        if (data.message && data.message.senderId !== currentUser?.id) {
          addMessage(data.message);
        }
        break;

      case 'error':
        toast({
          title: "Erreur",
          description: data.message,
          variant: "destructive"
        });
        break;

      case 'delete_message':
        if (data.messageId) {
          // Remove from local state - this will be handled by the MessageList component
          // No need to filter here as we use the context
        }
        break;
    }
  };

  const { connect, disconnect, sendMessage: sendWebSocketMessage } = useWebSocket({
    onMessage: handleWebSocketMessage,
    onOpen: () => {
      console.log('WebSocket opened, joining room...');
      setConnectionStatus('connected');
      setIsConnected(true);
      sendWebSocketMessage({
        type: 'join_room',
        username,
        roomId: roomCode,
        role
      });
    },
    onClose: () => {
      console.log('WebSocket closed');
      setConnectionStatus('disconnected');
      setIsConnected(false);
    },
    onError: () => {
      console.log('WebSocket error occurred');
      setConnectionStatus('error');
      setIsConnected(false);
    }
  });

  const handleWebRTCMessage = async (message: Message) => {
    // Decrypt message if encrypted
    try {
      // For now, messages come decrypted from WebRTC
      addMessage(message);
    } catch (error) {
      console.error('Failed to decrypt message:', error);
    }
  };

  const { 
    sendMessage: sendWebRTCMessage,
    createAnswer,
    handleAnswer,
    handleIceCandidate
  } = useWebRTC({
    onMessage: handleWebRTCMessage,
    localUserId: currentUser?.id || '',
    localUsername: username
  });

  useEffect(() => {
    setConnectionStatus('connecting');
    connect();
    return () => {
      disconnect();
    };
  }, []); // Empty dependency array to avoid reconnection loops

  const handleSendMessage = async (content: string, type: 'text' | 'image' = 'text', imageData?: string) => {
    if (!currentUser) return;

    const message: Message = {
      id: `${currentUser.id}-${Date.now()}`,
      content,
      senderId: currentUser.id,
      senderName: currentUser.username,
      timestamp: Date.now(),
      type: type === 'image' ? 'image' : 'user',
      imageUrl: imageData,
      reactions: []
    };

    // Add to local messages immediately
    addMessage(message);

    try {
      // For now, send messages directly without encryption for simplicity
      // This ensures messages work while we can add encryption later
      sendWebRTCMessage(message);
      
      // Also broadcast via WebSocket for users who don't have P2P connection yet
      sendWebSocketMessage({
        type: 'broadcast_message',
        message: message
      });
    } catch (error) {
      console.error('Failed to send message:', error);
      toast({
        title: "Erreur",
        description: "Impossible d'envoyer le message",
        variant: "destructive"
      });
    }
  };

  const handleTypingStart = () => {
    sendWebSocketMessage({ type: 'typing_start' });
  };

  const handleTypingStop = () => {
    sendWebSocketMessage({ type: 'typing_stop' });
  };

  const handleClearMessages = () => {
    if (role === 'admin') {
      clearMessages();
      toast({
        title: "Succès",
        description: "Tous les messages ont été effacés",
      });
    }
  };

  const handleExportConversation = () => {
    const conversationText = messages
      .filter(m => m.type === 'user')
      .map(m => `[${new Date(m.timestamp).toLocaleString('fr-FR')}] ${m.senderName}: ${m.content}`)
      .join('\n');
    
    const blob = new Blob([conversationText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `conversation-${roomCode}-${new Date().toISOString().split('T')[0]}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    toast({
      title: "Succès",
      description: "Conversation exportée avec succès !",
    });
  };

  const handleCloseRoom = () => {
    closeRoom();
    toast({
      title: "Salle clôturée",
      description: "La salle a été fermée. Les nouveaux utilisateurs ne peuvent plus rejoindre.",
      variant: "destructive"
    });
  };

  const handleDeleteMessage = (messageId: string) => {
    // Broadcast deletion to other users
    sendWebSocketMessage({
      type: 'delete_message',
      messageId,
      timestamp: Date.now()
    });
  };

  const toggleTheme = () => {
    setIsDarkMode(!isDarkMode);
    document.documentElement.classList.toggle('dark');
  };

  const copyRoomCode = async () => {
    try {
      await navigator.clipboard.writeText(roomCode);
      toast({
        title: "Succès",
        description: "Code de salle copié dans le presse-papiers !",
      });
    } catch (error) {
      toast({
        title: "Erreur",
        description: "Impossible de copier le code de salle",
        variant: "destructive"
      });
    }
  };

  const shareRoom = async () => {
    const shareUrl = `${window.location.origin}?room=${roomCode}`;
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Rejoignez ma salle de chat',
          text: `Rejoignez-moi dans la salle ${roomCode}`,
          url: shareUrl
        });
      } catch (error) {
        // Fallback to copy
        await navigator.clipboard.writeText(shareUrl);
        toast({
          title: "Lien copié",
          description: "Le lien de partage a été copié dans le presse-papiers",
        });
      }
    } else {
      await navigator.clipboard.writeText(shareUrl);
      toast({
        title: "Lien copié",
        description: "Le lien de partage a été copié dans le presse-papiers",
      });
    }
  };

  const typingText = typingUsers.length > 0 
    ? `${typingUsers.join(', ')} ${typingUsers.length === 1 ? 'est en train' : 'sont en train'} d'écrire...`
    : '';

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-2 md:p-4">
      <div className="w-full max-w-7xl mx-auto bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl md:rounded-3xl shadow-2xl overflow-hidden">
        
        {/* Header */}
        <header className="bg-gradient-to-r from-purple-600 to-pink-600 text-white p-4 md:p-6 relative">
          <div className="flex items-center justify-between">
            {/* Back Button & Menu - Mobile */}
            <div className="flex items-center gap-2 lg:hidden">
              <Button
                onClick={onLeave}
                className="bg-white/20 hover:bg-white/30 p-2 rounded-lg transition-colors"
                data-testid="button-back-mobile"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
              </Button>
              <Button
                onClick={() => setShowMenu(!showMenu)}
                className="bg-white/20 hover:bg-white/30 p-2 rounded-lg transition-colors"
                data-testid="button-menu"
              >
                <div className="flex flex-col space-y-1 w-4 h-3 justify-center">
                  <div className="h-0.5 bg-white rounded"></div>
                  <div className="h-0.5 bg-white rounded"></div>
                  <div className="h-0.5 bg-white rounded"></div>
                </div>
              </Button>
            </div>
            
            {/* App Icon - Desktop */}
            <div className="hidden lg:flex items-center gap-3">
              <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
                <FaComments className="text-xl text-yellow-400" />
              </div>
            </div>
            
            {/* App Title & Status */}
            <div className="text-center">
              <h1 className="text-2xl md:text-3xl font-bold">
                TalkRoom
              </h1>
              <div className="flex items-center justify-center gap-2 text-sm opacity-90 mt-1" data-testid="current-user-info">
                <div className={`w-2 h-2 rounded-full ${
                  connectionStatus === 'connected' ? 'bg-green-400 animate-pulse-slow' : 
                  connectionStatus === 'connecting' ? 'bg-yellow-400 animate-pulse' :
                  connectionStatus === 'error' ? 'bg-red-400 animate-pulse' : 
                  'bg-gray-400'
                }`}></div>
                <span>{username} ({
                  connectionStatus === 'connected' ? 'en ligne' :
                  connectionStatus === 'connecting' ? 'connexion...' :
                  connectionStatus === 'error' ? 'erreur de connexion' :
                  'hors ligne'
                })</span>
              </div>
            </div>
            
            {/* Leave Button */}
            <div className="flex items-center gap-3">
              <Button
                onClick={onLeave}
                className="bg-red-500/20 hover:bg-red-500/30 text-red-300 border border-red-500/30 px-3 py-1 rounded-lg text-sm transition-colors"
                data-testid="button-leave-room"
              >
                <FaDoorOpen className="mr-1" />
                <span className="hidden md:inline">Quitter</span>
              </Button>
            </div>
          </div>
          
          {/* Theme Toggle */}
          {/***<Button
            onClick={toggleTheme}
            className="absolute top-4 right-4 p-2 rounded-lg glass-effect hover:bg-white/10 transition-colors"
            data-testid="button-toggle-theme"
          >
            <FaSun className={`text-yellow-400 ${isDarkMode ? 'block' : 'hidden'}`} />
            <FaMoon className={`text-white ${isDarkMode ? 'hidden' : 'block'}`} />
          </Button> */}
          
        </header>

        {/* Mobile Slide Menu Overlay */}
        {showMenu && (
          <div 
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40 lg:hidden"
            onClick={() => setShowMenu(false)}
          />
        )}

        {/* Mobile Slide Menu */}
        <div className={`fixed top-0 left-0 h-full w-80 bg-gradient-to-b from-purple-900 via-slate-900 to-slate-900 transform transition-transform duration-300 ease-in-out z-50 border-r border-white/20 lg:hidden ${
          showMenu ? 'translate-x-0' : '-translate-x-full'
        }`}>
          <div className="p-6">
            {/* Menu Header */}
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-white">Menu</h2>
              <Button
                onClick={() => setShowMenu(false)}
                className="bg-white/20 hover:bg-white/30 p-2 rounded-lg transition-colors"
              >
                <FaTimes className="text-white" />

              </Button>
            </div>

            {/* Room Sharing Section */}
            <div className="mb-6">
              <div className="bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-2xl p-4">
                <h3 className="font-semibold mb-3 flex items-center gap-2">
                  <FaShareAlt className="text-blue-300" />
                  Partager la salle
                </h3>
                <div className="bg-white/20 backdrop-blur rounded-lg p-3 text-sm font-mono mb-3" data-testid="room-code-display">
                  {roomCode}
                </div>
                <div className="flex flex-col gap-2">
                  <Button
                    onClick={copyRoomCode}
                    className="bg-white/20 hover:bg-white/30 px-4 py-2 rounded-lg text-sm transition-colors"
                    data-testid="button-copy-room-code"
                  >
                    <FaClipboard className="mr-2" />
                    Copier le code
                  </Button>
                  <Button
                    onClick={shareRoom}
                    className="bg-white/20 hover:bg-white/30 px-4 py-2 rounded-lg text-sm transition-colors"
                    data-testid="button-share-room"
                  >
                    <FaLink className="mr-2" />
                    Partager le lien
                  </Button>
                </div>
              </div>
            </div>

            {/* Statistics Section */}
            <div className="mb-6">
              <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-4 border border-white/10">
                <h3 className="font-semibold text-white mb-4 flex items-center gap-2">
                  <FaChartBar className="text-purple-400" />
                  Statistiques
                </h3>
                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-white/10 rounded-lg p-3 text-center">
                    <div className="text-2xl font-bold text-purple-400" data-testid="stat-message-count">
                      {messageCount}
                    </div>
                    <div className="text-xs text-white/60">Messages</div>
                  </div>
                  <div className="bg-white/10 rounded-lg p-3 text-center">
                    <div className="text-2xl font-bold text-green-400" data-testid="stat-user-count">
                      {participants.length}
                    </div>
                    <div className="text-xs text-white/60">Utilisateurs</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Users List Section */}
            <div className="mb-6">
              <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-4 border border-white/10">
                <h3 className="font-semibold text-white mb-4 flex items-center gap-2">
                  <FaUsers className="text-green-400" />
                  Utilisateurs connectés
                </h3>
                <div className="space-y-2" data-testid="users-list">
                  {participants.map((user) => (
                    <div 
                      key={user.id} 
                      className="flex items-center justify-between p-3 bg-white/10 rounded-lg border-l-4 border-green-400"
                      data-testid={`user-item-${user.id}`}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`w-2 h-2 rounded-full ${user.isOnline ? 'bg-green-400 animate-pulse-slow' : 'bg-gray-400'}`}></div>
                        <span className="font-medium text-white">
                          {user.id === currentUser?.id ? 'Vous' : user.username}
                          {user.isOnline && ' (en ligne)'}
                        </span>
                      </div>
                      <span className="text-xs text-white/60 capitalize">
                        {user.role === 'admin' ? 'Admin' : 'User'}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Admin Controls */}
            {role === 'admin' && (
              <div className="mb-6">
                <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-4 border border-white/10">
                  <h3 className="font-semibold text-white mb-4 flex items-center gap-2">
                    <FaShieldAlt className="text-amber-400" />
                    Contrôles Admin
                  </h3>
                  <div className="space-y-2">
                    <Button
                      onClick={() => {
                        handleClearMessages();
                        setShowMenu(false);
                      }}
                      className="w-full bg-red-500/20 hover:bg-red-500/30 text-red-300 border border-red-500/30 py-2 px-4 rounded-lg text-sm transition-colors"
                      data-testid="button-clear-messages"
                    >
                      <FaTrash className="mr-2" />
                      Effacer tous les messages
                    </Button>
                    <Button
                      onClick={() => {
                        handleExportConversation();
                        setShowMenu(false);
                      }}
                      className="w-full bg-blue-500/20 hover:bg-blue-500/30 text-blue-300 border border-blue-500/30 py-2 px-4 rounded-lg text-sm transition-colors"
                      data-testid="button-export-conversation"
                    >
                      <FaFileExport className="mr-2" />
                      Exporter la conversation
                    </Button>
                    <Button
                      onClick={() => {
                        handleCloseRoom();
                        setShowMenu(false);
                      }}
                      className="w-full bg-orange-500/20 hover:bg-orange-500/30 text-orange-300 border border-orange-500/30 py-2 px-4 rounded-lg text-sm transition-colors"
                      data-testid="button-close-room"
                    >
                      <FaBan className="mr-2" />
                      Clôturer la salle
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Chat Section */}
        <section className="p-3 md:p-6">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-3 md:gap-6 h-[70vh] md:h-[600px]">
            
            {/* Messages Area - Left Column */}
            <div className="lg:col-span-3 flex flex-col">
              <MessageList 
                messages={messages} 
                currentUserId={currentUser?.id || ''} 
                onAddReaction={(messageId, emoji) => {
                  if (currentUser) {
                    addReaction(messageId, emoji, currentUser.id, currentUser.username);
                  }
                }}
                onDeleteMessage={handleDeleteMessage}
              />
              
              {/* Typing Indicator */}
              <div className="text-sm text-white/70 italic mb-3 h-5 animate-fade-in-out" data-testid="typing-indicator">
                {typingText}
              </div>
              
              <MessageInput
                onSendMessage={handleSendMessage}
                onTypingStart={handleTypingStart}
                onTypingStop={handleTypingStop}
                disabled={!isConnected}
              />
            </div>
            
            {/* Sidebar - Right Column (Desktop Only) */}
            <div className="hidden lg:block lg:col-span-1 space-y-4 overflow-y-auto">
              
              {/* Room Sharing Section */}
              <div className="bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-2xl p-4">
                <h3 className="font-semibold mb-3 flex items-center gap-2">
                 
                  <FaShare className="text-blue-300" />
                  Partager
                </h3>
                <div className="bg-white/20 backdrop-blur rounded-lg p-3 text-sm font-mono mb-3" data-testid="room-code-display">
                  {roomCode}
                </div>
                <div className="flex flex-col gap-2">
                  <Button
                    onClick={copyRoomCode}
                    className="bg-white/20 hover:bg-white/30 px-3 py-2 rounded-lg text-sm transition-colors"
                    data-testid="button-copy-room-code"
                  >
                    <FaClipboard className="mr-2" />
                    Copier code
                  </Button>
                  <Button
                    onClick={shareRoom}
                    className="bg-white/20 hover:bg-white/30 px-3 py-2 rounded-lg text-sm transition-colors"
                    data-testid="button-share-room"
                  >
                    <FaLink className="mr-2" />
                    Partager lien
                  </Button>
                </div>
              </div>

              {/* Statistics Section */}
              <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-4 border border-white/10">
                <h3 className="font-semibold text-white mb-4 flex items-center gap-2">
                  <FaChartBar className="text-purple-400" />
                  Statistiques
                </h3>
                <div className="grid grid-cols-1 gap-3">
                  <div className="bg-white/10 rounded-lg p-3 text-center">
                    <div className="text-2xl font-bold text-purple-400" data-testid="stat-message-count">
                      {messageCount}
                    </div>
                    <div className="text-xs text-white/60">Messages</div>
                  </div>
                  <div className="bg-white/10 rounded-lg p-3 text-center">
                    <div className="text-2xl font-bold text-green-400" data-testid="stat-user-count">
                      {participants.length}
                    </div>
                    <div className="text-xs text-white/60">Utilisateurs</div>
                  </div>
                </div>
              </div>

              {/* Users List Section */}
              <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-4 border border-white/10">
                <h3 className="font-semibold text-white mb-4 flex items-center gap-2">
                  <FaUsers className="text-green-400" />
                  Connectés
                </h3>
                <div className="space-y-2" data-testid="users-list">
                  {participants.map((user) => (
                    <div 
                      key={user.id} 
                      className="flex items-center justify-between p-2 bg-white/10 rounded-lg border-l-4 border-green-400"
                      data-testid={`user-item-${user.id}`}
                    >
                      <div className="flex items-center gap-2">
                        <div className={`w-2 h-2 rounded-full ${user.isOnline ? 'bg-green-400 animate-pulse-slow' : 'bg-gray-400'}`}></div>
                        <span className="font-medium text-white text-sm">
                          {user.id === currentUser?.id ? 'Vous' : user.username}
                        </span>
                      </div>
                      <span className="text-xs text-white/60 capitalize">
                        {user.role === 'admin' ? 'Admin' : 'User'}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Admin Controls */}
              {role === 'admin' && (
                <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-4 border border-white/10">
                  <h3 className="font-semibold text-white mb-4 flex items-center gap-2">
                    <FaShieldAlt className="text-amber-400" />
                    Admin
                  </h3>
                  <div className="space-y-2">
                    <Button
                      onClick={handleClearMessages}
                      className="w-full bg-red-500/20 hover:bg-red-500/30 text-red-300 border border-red-500/30 py-2 px-3 rounded-lg text-sm transition-colors"
                      data-testid="button-clear-messages"
                    >
                      <FaTrash className="mr-2" />
                      Effacer messages
                    </Button>
                    <Button
                      onClick={handleExportConversation}
                      className="w-full bg-blue-500/20 hover:bg-blue-500/30 text-blue-300 border border-blue-500/30 py-2 px-3 rounded-lg text-sm transition-colors"
                      data-testid="button-export-conversation"
                    >
                      <FaFileExport className="mr-2" />
                      Exporter
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
